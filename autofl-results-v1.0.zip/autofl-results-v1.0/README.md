# AutoFL — Experimental Results and Figures

This Zenodo deposit contains the raw experimental outputs and publication
figures of:

> *AutoFL: Skill-Level Prompting Strategies for Automated Federated Learning
> Client Generation*, IEEE Transactions on Neural Networks and Learning
> Systems (under review, 2026).

For the source code that produced these results, see the companion deposit
`autofl-system-v*.zip` (DOI to be filled in).

## File map (CSV / JSON → paper figures and tables)

| File | Paper artifact | Description |
|------|----------------|-------------|
| `results/benchmark.csv` | Tab. I, Fig. 2, Fig. 3, Fig. 5 | 40-run primary benchmark (10 scripts × 4 strategies); per-stage failures, κ, e2e_runnable |
| `results/benchmark_extended.csv` | Tab. IV | 12 additional non-DL runs (sklearn × 2, XGBoost × 1) |
| `results/comparison_multimodel.csv` | Tab. VII | Cross-provider 6-script subset (Claude vs Gemini 2.5 Flash vs Ollama Llama 3 8B) |
| `results/exemplar_correction.csv` | §5.9 dry-run | Dry-run patch of the corrected exemplar (upper bound = 4/10) |
| `results/exemplar_correction_realapi.csv` | §5.9 real-API | Real-API re-run with corrected exemplar on Gemini 2.5 Flash (3/10) |
| `results/hardware_sweep.csv` | Fig. 8 | 16-config batch × lr sweep, CPU-only MNIST |
| `results/non_dl_proxy_validation.csv` | Fig. 9 (Tab. V) | PyTorch-proxy vs native sklearn/XGBoost accuracy on Digits, Iris, Breast Cancer |
| `fl_results/simulation_results.json` | Tab. VI, Fig. 7 | PyTorch MNIST (3 clients, 5 rounds) + Lightning GAN (2 clients, 3 rounds), per-round loss |
| `fl_results/simulation_non_iid_results.json` | Tab. IX | Non-IID training-loss trajectories: IID, Dirichlet α=0.5, α=0.1; centralized baseline |
| `fl_results/non_iid_accuracy_results.json` | Tab. VIII | Held-out test accuracy per round for the three Dirichlet settings |
| `*_notes.md` (each subdir) | Methods cross-reference | Per-experiment provenance: config, seed, hardware, command line |

## Figures (vector PDF + raster PNG where applicable)

```
figures/
├── fig0_architecture.pdf       # Fig. 1 (system overview)
├── fig1_e2e_heatmap.pdf        # Fig. 2 (e2e success by strategy × framework)
├── fig2_coverage_grouped.pdf   # Fig. 3 (κ vs e2e_runnable bar chart)
├── fig3_stage_breakdown.pdf    # Fig. 4 (per-stage failure)
├── fig4_per_script.pdf         # Fig. 5 (per-script e2e success matrix)
├── fig5_fl_convergence.pdf     # Fig. 7 (FL loss curves)
├── fig6_hardware_sweep.pdf     # Fig. 8 (hardware heatmap)
├── fig7_non_iid.pdf            # Fig. 9 (non-IID convergence + test accuracy)
└── fig8_non_dl_validation.pdf  # Fig. 10 (PyTorch-proxy validation)
```

Plus the architecture figure source: `gen_architecture_fig.py`.

## Compiled paper

`main_journal.pdf` — 19-page compiled manuscript (for reference; this is the
version corresponding to the data here).

## Re-deriving statistics

The CSVs are self-contained. The exact p-values reported in the paper can be
re-derived with:

```python
import pandas as pd
from scipy.stats import fisher_exact

df = pd.read_csv("results/benchmark.csv")
# Few-shot 1/10 vs Structured 10/10
print(fisher_exact([[1, 9], [10, 0]]))  # p ≈ 1.2e-4
```

Non-IID loss reductions:

```python
import json
data = json.load(open("fl_results/simulation_non_iid_results.json"))
for name in ("iid", "dirichlet_0.5", "dirichlet_0.1"):
    r1 = data[name]["rounds"][0]["aggregated_loss"]
    r5 = data[name]["rounds"][-1]["aggregated_loss"]
    print(f"{name}: {(1 - r5/r1)*100:.1f}% reduction ({r1:.3f} -> {r5:.3f})")
# iid: 75.0% reduction (0.306 -> 0.077)
# dirichlet_0.5: 72.1% reduction (0.260 -> 0.072)
# dirichlet_0.1: 63.5% reduction (0.126 -> 0.046)
```

## Citation

```bibtex
@misc{autofl_results_2026,
  title  = {AutoFL: Experimental Results and Figures},
  author = {Chiu, Yen-Jung},
  year   = {2026},
  doi    = {10.5281/zenodo.XXXXXXX},
  note   = {Companion data for the AutoFL paper}
}
```
