"""Generate AutoFL architecture diagram (fig0_architecture.pdf/png)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from pathlib import Path

fig, ax = plt.subplots(figsize=(11, 4.5))
ax.set_xlim(0, 11)
ax.set_ylim(0, 4.5)
ax.axis("off")

BLUE   = "#2563EB"
GREEN  = "#16A34A"
ORANGE = "#D97706"
RED    = "#DC2626"
GRAY   = "#6B7280"
LBLUE  = "#DBEAFE"
LGREEN = "#DCFCE7"
LYELLOW= "#FEF9C3"
LGRAY  = "#F3F4F6"

def box(ax, x, y, w, h, fc, ec, label, sublabel="", fontsize=10):
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.08",
                       facecolor=fc, edgecolor=ec, linewidth=1.5, zorder=2)
    ax.add_patch(p)
    ax.text(x + w/2, y + h/2 + (0.18 if sublabel else 0), label,
            ha="center", va="center", fontsize=fontsize, fontweight="bold", color=ec, zorder=3)
    if sublabel:
        ax.text(x + w/2, y + h/2 - 0.22, sublabel,
                ha="center", va="center", fontsize=8, color=GRAY, zorder=3, style="italic")

def arrow(ax, x1, y1, x2, y2, color=GRAY):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", color=color, lw=1.5), zorder=4)

# ─── Title ───────────────────────────────────────────────────────────
ax.text(5.5, 4.2, "AutoFL System Pipeline", ha="center", va="center",
        fontsize=13, fontweight="bold", color="#1F2937")

# ─── Input ───────────────────────────────────────────────────────────
box(ax, 0.2, 1.5, 1.7, 1.2, LGRAY, GRAY, "Input ML\nScript",
    "PyTorch / TF\nMONAI / Lightning\nsklearn / XGBoost", fontsize=9)

# ─── Converter box (4 strategies) ────────────────────────────────────
conv_box = FancyBboxPatch((2.3, 0.3), 3.2, 3.8, boxstyle="round,pad=0.1",
                          facecolor="#EFF6FF", edgecolor=BLUE, linewidth=2, zorder=1)
ax.add_patch(conv_box)
ax.text(3.9, 3.85, "AutoFL Converter", ha="center", va="center",
        fontsize=11, fontweight="bold", color=BLUE)

for i, (lbl, fc, ec) in enumerate([
    ("AST (rule-based)", LGRAY, GRAY),
    ("Zero-shot LLM",   LYELLOW, ORANGE),
    ("Few-shot LLM",    LYELLOW, ORANGE),
    ("Structured LLM ★", LGREEN, GREEN),
]):
    box(ax, 2.5, 2.55 - i * 0.72, 2.8, 0.55, fc, ec, lbl, fontsize=8.5)

# ─── Output ──────────────────────────────────────────────────────────
box(ax, 5.9, 1.5, 1.8, 1.2, LGREEN, GREEN, "FL Client\nModule",
    "build_model()\nbuild_dataloader()\ntrain_step()", fontsize=8.5)

# ─── Preflight ───────────────────────────────────────────────────────
pf_box = FancyBboxPatch((8.05, 0.3), 2.75, 3.8, boxstyle="round,pad=0.1",
                        facecolor="#FEF3C7", edgecolor=ORANGE, linewidth=2, zorder=1)
ax.add_patch(pf_box)
ax.text(9.43, 3.85, "5-Stage Preflight", ha="center", va="center",
        fontsize=11, fontweight="bold", color=ORANGE)
stages = ["S1: Import check", "S2: Hardware detect",
          "S3: Data load", "S4: Forward pass", "S5: Backward pass ✓"]
for i, s in enumerate(stages):
    ax.text(9.43, 3.3 - i*0.6, s, ha="center", va="center", fontsize=8,
            color="#92400E" if i < 4 else GREEN, fontweight="normal" if i < 4 else "bold")

# ─── Result annotation ───────────────────────────────────────────────
box(ax, 8.1, 0.3, 2.65, 0.75, LGREEN, GREEN, "e2e_runnable + component_coverage κ", fontsize=7.5)

# ─── Arrows ──────────────────────────────────────────────────────────
arrow(ax, 1.92, 2.1, 2.28, 2.1, BLUE)    # input → converter
arrow(ax, 5.52, 2.1, 5.88, 2.1, GREEN)   # converter → output
arrow(ax, 7.72, 2.1, 8.03, 2.1, ORANGE)  # output → preflight

# ─── FedAvg box below ────────────────────────────────────────────────
ax.annotate("", xy=(9.43, 1.08), xytext=(9.43, 1.38),
            arrowprops=dict(arrowstyle="-|>", color=ORANGE, lw=1.5), zorder=4)

out = Path(__file__).parent / "figures"
out.mkdir(exist_ok=True)
for ext in ("pdf", "png"):
    p = out / f"fig0_architecture.{ext}"
    fig.savefig(str(p), dpi=300, bbox_inches="tight")
    print(f"Saved {p}")
plt.close(fig)
